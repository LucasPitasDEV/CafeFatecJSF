package Conversor;

import Dao.TipoDAO;
import Modelo.Tipo;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

@FacesConverter("TipoConverter")
public class TipoConverter implements Converter{

    @Override
    public Object getAsObject(FacesContext context, UIComponent component, String value) {
        Tipo obj = null;
        TipoDAO dao = new TipoDAO();
        try{
            obj = dao.procurarPorId(Integer.parseInt(value));
        } catch (Exception e){
            System.out.println("Erro no conversor Tipo - getAsObject");
        }
        return obj;
        
    }

    @Override
    public String getAsString(FacesContext fc, UIComponent uic, Object o) {
        try{
            Tipo obj = (Tipo) o;
            return String.valueOf(obj.getId());
        } catch (Exception e){
            System.out.println("Erro no conversor Tipo - getAsString");
            return "";
        }
    }
    
}
