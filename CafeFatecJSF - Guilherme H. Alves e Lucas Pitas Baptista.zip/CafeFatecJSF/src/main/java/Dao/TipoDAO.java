package Dao;

import Modelo.Tipo;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.Query;

public class TipoDAO extends GenericDAO<Tipo> {

    @Override
    public Tipo procurarPorId(Integer id) {
        EntityManager em = JPAUtil.getEntityManager();
        Tipo obj = null;
        try {
            Query q = em.createQuery("select t from Tipo t where t.id =:id", Tipo.class);
            q.setParameter("id", id);
            obj = (Tipo) q.getSingleResult();
            em.close();
            return obj;
        } catch (Exception ex) {
            ex.getMessage();
            return null;
        }
    }

    @Override
    public List<Tipo> listarTodos() {
        try {
            EntityManager em = JPAUtil.getEntityManager();
            Query q = em.createQuery("select t from Tipo t", Tipo.class);
            List<Tipo> lista = q.getResultList();
            return lista;
        } catch (Exception ex) {
            ex.getMessage();
            return null;
        }
    }

    @Override
    public String salvar(Tipo obj) {
        if (procurarPorId(obj.getId()) == null) {
            return this.add(obj);
        } else {
            return this.update(obj);
        }
    }

}
