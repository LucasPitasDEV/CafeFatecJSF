package Dao;

import Modelo.Produto;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.Query;

public class ProdutoDAO extends GenericDAO<Produto> {

    @Override
    public Produto procurarPorId(Integer id) {
        EntityManager em = JPAUtil.getEntityManager();
        Produto obj = null;
        try {
            Query q = em.createQuery("select p from Produto p where p.id =:id", Produto.class);
            q.setParameter("id", id);
            obj = (Produto) q.getSingleResult();
            em.close();
            return obj;
        } catch (Exception ex) {
            ex.getMessage();
            return null;
        }
    }

    @Override
    public List<Produto> listarTodos() {
        try {
            EntityManager em = JPAUtil.getEntityManager();
            Query q = em.createQuery("select p from Produto p", Produto.class);
            List<Produto> lista = q.getResultList();
            return lista;
        } catch (Exception ex) {
            ex.getMessage();
            return null;
        }
    }

    @Override
    public String salvar(Produto obj) {
        if (procurarPorId(obj.getId()) == null) {
            return this.add(obj);
        } else {
            return this.update(obj);
        }
    }

}
