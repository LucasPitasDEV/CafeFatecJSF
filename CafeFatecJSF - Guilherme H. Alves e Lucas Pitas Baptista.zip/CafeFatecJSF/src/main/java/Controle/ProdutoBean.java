package Controle;

import Dao.TipoDAO;
import Dao.ProdutoDAO;
import Modelo.Tipo;
import Modelo.Produto;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

@ManagedBean
@ViewScoped
public class ProdutoBean {

    private Produto produto;
    private int idTab;
    private List<Produto> listaProdutos;
    private List<Tipo> listaTipos;

    public ProdutoBean() {
        prepararTela();
    }

    public Produto getProduto() {
        return produto;
    }

    public void setProduto(Produto produto) {
        this.produto = produto;
    }

    public int getIdTab() {
        return idTab;
    }

    public void setIdTab(int idTab) {
        this.idTab = idTab;
    }

    public List<Produto> getListaProdutos() {
        if (listaProdutos == null) {
            ProdutoDAO dao = new ProdutoDAO();
            listaProdutos = dao.listarTodos();
        }
        return listaProdutos;
    }

    public void setListaProdutos(List<Produto> listaProdutos) {
        this.listaProdutos = listaProdutos;
    }

    public List<Tipo> getListaTipos() {
        if (listaTipos == null) {
            TipoDAO dao = new TipoDAO();
            listaTipos = dao.listarTodos();
        }
        return listaTipos;
    }

    public void setListaTipos(List<Tipo> listaTipos) {
        this.listaTipos = listaTipos;
    }

    private void prepararTela() {
        produto = new Produto();
        listaTipos = null;
        listaProdutos = null;
        idTab = 0;
    }

    public void limpar() {
        prepararTela();
        idTab = 1;
    }

    public void editar(Produto produto) {
        this.produto = produto;
        idTab = 1;
    }

    public void excluir(Produto produto) {
        ProdutoDAO dao = new ProdutoDAO();
        String msg = dao.delete(produto);
        FacesContext fc = FacesContext.getCurrentInstance();
        FacesMessage fm = new FacesMessage(FacesMessage.SEVERITY_WARN,
                "Sucesso ao Excluir", msg);
        fc.addMessage(null, fm);
        prepararTela();
    }

    public void salvar() {
        FacesMessage fm;
        String msg = "";
        if (produto.getNome().isEmpty() || produto.getPreco()<=0) {
            msg = "Campos: nome e preço são obrigatórios";
            fm = new FacesMessage(FacesMessage.SEVERITY_ERROR,
                    "Campos sem Preencher", msg);
        } else {
            ProdutoDAO dao = new ProdutoDAO();
            msg = dao.salvar(produto);
            fm = new FacesMessage(FacesMessage.SEVERITY_INFO,
                    "Sucesso ao Salvar", msg);
        }
        FacesContext fc = FacesContext.getCurrentInstance();
        fc.addMessage(null, fm);
        prepararTela();
        idTab = 1;
    }

}
