package Controle;

import Dao.TipoDAO;
import Modelo.Tipo;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

@ManagedBean
@ViewScoped
public class TipoBean {

    private Tipo tipo;
    private int idTab;
    private List<Tipo> listaTipos;

    public TipoBean() {
        prepararTela();
    }

    public Tipo getTipo() {
        return tipo;
    }

    public void setTipo(Tipo tipo) {
        this.tipo = tipo;
    }

    public int getIdTab() {
        return idTab;
    }

    public void setIdTab(int idTab) {
        this.idTab = idTab;
    }

    public List<Tipo> getListaTipos() {
        if (listaTipos == null) {
            TipoDAO dao = new TipoDAO();
            listaTipos = dao.listarTodos();
        }
        return listaTipos;
    }

    public void setListaTipos(List<Tipo> listaTipos) {
        this.listaTipos = listaTipos;
    }

    private void prepararTela() {
        tipo = new Tipo();
        listaTipos = null;
        idTab = 0;
    }
    
    public void limpar() {
        prepararTela();
        idTab = 1;
    }

    public void editar(Tipo tipo) {
        this.tipo = tipo;
        idTab = 1;
    }

    public void excluir(Tipo obj) {
        TipoDAO dao = new TipoDAO();
        String msg = dao.delete(obj);
        FacesContext fc = FacesContext.getCurrentInstance();
        FacesMessage fm = new FacesMessage(FacesMessage.SEVERITY_WARN,
                "Sucesso ao Excluir", msg);
        fc.addMessage(null, fm);
        prepararTela();
    }

    public void salvar() {
        FacesMessage fm;
        String msg = "";
        if (tipo.getDescricao().isEmpty()) {
            msg = "Campo: Descrição é obrigatório";
            fm = new FacesMessage(FacesMessage.SEVERITY_ERROR,
                    "Campos sem Preencher", msg);
        } else {
            TipoDAO dao = new TipoDAO();
            msg = dao.salvar(tipo);
            fm = new FacesMessage(FacesMessage.SEVERITY_INFO,
                    "Sucesso ao Salvar", msg);
        }
        FacesContext fc = FacesContext.getCurrentInstance();
        fc.addMessage(null, fm);
        prepararTela();
        idTab = 1;
    }

}
